# K-Means Clustering

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans

# Importing the dataset
dataset = pd.read_excel('Mall_Customers.xlsx')

dataset.columns

print(dataset.head())

print(dataset.shape)

print(len(dataset))

print(dataset.info())


data = dataset.iloc[:, [3, 4]].values


# Using the elbow method to find the optimal number of clusters


distance = []
K=range(1, 20)
for i in K:
    kmeans = KMeans(n_clusters = i, random_state = 42)
    kmeans.fit(data)
    distance.append(kmeans.inertia_)
    
plt.plot(K, distance)
plt.title('The Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()

len(data)

# Fitting K-Means to the dataset
kmeans = KMeans(n_clusters = 5, random_state = 42)
y_kmeans = kmeans.fit_predict(data)
len(y_kmeans)
y_kmeans.shape
type(y_kmeans)

dataset['result']=y_kmeans


cluster_0_points=dataset[dataset['result'] == 0].index

cluster_1_points=dataset[dataset['result'] == 1].index
cluster_2_points=dataset[dataset['result'] == 2].index
cluster_3_points=dataset[dataset['result'] == 3].index
cluster_4_points=dataset[dataset['result'] == 4].index


data[cluster_4_points]

# Visualising the clusters
plt.scatter(data[cluster_0_points, 0], data[cluster_0_points, 1], s = 100, c = 'red', label = 'Cluster 1')
plt.scatter(data[cluster_1_points, 0], data[cluster_1_points, 1], s = 100, c = 'blue', label = 'Cluster 2')
plt.scatter(data[cluster_2_points, 0], data[cluster_2_points, 1], s = 100, c = 'green', label = 'Cluster 3')
plt.scatter(data[cluster_3_points, 0], data[cluster_3_points, 1], s = 100, c = 'cyan', label = 'Cluster 4')
plt.scatter(data[cluster_4_points, 0], data[cluster_4_points, 1], s = 100, c = 'magenta', label = 'Cluster 5')

plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s = 300, c = 'yellow', label = 'Cluster Center')

plt.title('Clusters of customers')

plt.xlabel('Annual Income (k$)')

plt.ylabel('Spending Score (1-100)')

plt.legend()

plt.show()


kmeans.predict([[20,61]])
